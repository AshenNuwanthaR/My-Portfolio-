package lk.ijse.finalProject.controller;

//import animatefx.animation.FadeIn;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import lk.ijse.finalProject.DB.Dbconnection;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginFormController {
    public AnchorPane rootNode;
    public TextField txtUsername;
    public TextField txtPassword;

    public void btnSignInOnAction(ActionEvent actionEvent) throws IOException {
        AnchorPane rootNode = FXMLLoader.load(getClass().getResource("/view/signpage.fxml"));
        Scene scene = new Scene(rootNode);
        Stage stage = (Stage) this.rootNode.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Signup Page");
        stage.centerOnScreen();
       // new FadeIn(rootNode).play();
    }

    public void btnLoginOnAction(ActionEvent actionEvent) {
        String username = txtUsername.getText();
        String password = txtPassword.getText();
        try {
            checkCredintial(username,password);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    private void checkCredintial(String username, String password) throws SQLException {
        String sql = "SELECT user_name,password from User WHERE user_name = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,username);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
            String dbPassword = resultSet.getString("password");
            if (dbPassword.equals(password)){
                try {
                    navigateToTheHomePage();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else{
                new Alert(Alert.AlertType.ERROR,"Invalid Password").show();
            }
        } else {
            new Alert(Alert.AlertType.ERROR,"Can't find user").show();
        }
    }

    private void navigateToTheHomePage() throws IOException {
        BorderPane rootNode = FXMLLoader.load(getClass().getResource("/view/homePage.fxml"));
        Scene scene = new Scene(rootNode);
        Stage stage = (Stage) this.rootNode.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Maldeniya Hardware");
        stage.centerOnScreen();
       // new FadeIn(rootNode).play();
    }

    public void txtUserNameOnAction(ActionEvent actionEvent) {
        txtPassword.requestFocus();
    }

    public void txtPasswordOnAction(ActionEvent actionEvent) {
        btnLoginOnAction(actionEvent);
    }
}
