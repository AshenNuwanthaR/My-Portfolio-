package lk.ijse.finalProject.Model;


public class Payment {
    private String Payment_id;
    private double Payment_price;
    private String Description;
    private String Payment_methods;

    public Payment() {
    }

    public Payment(String payment_id, double payment_price, String description, String payment_methods) {
        Payment_id = payment_id;
        Payment_price = payment_price;
        Description = description;
        Payment_methods = payment_methods;
    }

    public String getPayment_id() {
        return Payment_id;
    }

    public void setPayment_id(String payment_id) {
        Payment_id = payment_id;
    }

    public double getPayment_price() {
        return Payment_price;
    }

    public void setPayment_price(double payment_price) {
        Payment_price = payment_price;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getPayment_methods() {
        return Payment_methods;
    }

    public void setPayment_methods(String payment_methods) {
        Payment_methods = payment_methods;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "Payment_id='" + Payment_id + '\'' +
                ", Payment_price=" + Payment_price +
                ", Description='" + Description + '\'' +
                ", Payment_methods='" + Payment_methods + '\'' +
                '}';
    }
}
