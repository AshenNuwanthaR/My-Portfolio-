package lk.ijse.finalProject.controller;




import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.finalProject.Repositories.CustomerRepo;

import java.io.IOException;
import java.sql.SQLException;

public class signpagecontroller {


    public TextField txtrepassword;
    public TextField txtpassword;
    public TextField txtusername;
    @FXML
    private AnchorPane rootNode;


    public void btnsinginaction(ActionEvent actionEvent) throws IOException, SQLException {

       String usename    =txtusername.getText();
       String password   =txtpassword.getText();
       String repassword =txtrepassword.getText();
       CustomerRepo.registerCustomer(usename,password,repassword);
    }

    public void btnbackaction(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) this.rootNode.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(this.getClass().getResource("/view/loginForm.fxml"))));
        stage.setTitle("Login Form");
        stage.centerOnScreen();
    }
}
