package lk.ijse.finalProject.Model;

public class Customer {
    private String customer_id;
    private String name;
    private int contactNumber;
    private String address;

    public Customer(String nextId, double paymentprice, String description, String paymentmethod) {
    }

    public Customer(String customer_id, String name, int contactNumber, String address) {
        this.customer_id = customer_id;
        this.name = name;
        this.contactNumber = contactNumber;
        this.address = address;
    }

    public Customer(String name, int tel, String address) {
        this.name = name;
        this.contactNumber = tel;
        this.address =address;
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(int contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customer_id='" + customer_id + '\'' +
                ", name='" + name + '\'' +
                ", contactNumber=" + contactNumber +
                ", address='" + address + '\'' +
                '}';
    }
}


