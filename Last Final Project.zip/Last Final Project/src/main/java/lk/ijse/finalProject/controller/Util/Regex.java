package lk.ijse.finalProject.controller.Util;

import javafx.scene.paint.Paint;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
    public static boolean isTextFieldValid(TextField textField, String text){
        String filed ="";

        switch (textField){
            case Name:
                filed = "^[A-z|\\\\s]{3,}$";
                break;
            case Number:
                filed = "^\\d+$";
                break;
            case Address:
                filed = "^[A-z|\\\\s]{3,}$";
                break;
            case Price:
                filed = "^([0-9]){1,}[.]([0-9]){1,}$";
                break;
            case Qty:
                filed = "^\\d+$";

        }
        Pattern pattern = Pattern.compile(filed);

        if (text != null){
            if (text.trim().isEmpty()){
                return false;
            }
        }else {
            return false;
        }

        Matcher matcher = pattern.matcher(text);

        if (matcher.matches()){
            return true;
        }
        return false;
    }
    public static boolean setTextColour(TextField location,javafx.scene.control.TextField textField){
        if (Regex.isTextFieldValid(location, textField.getText())){
            textField.setStyle("-fx-text-fill: Green;");
            textField.setStyle("-fx-text-fill: Green;");

            return true;
        }else {
            textField.setStyle("-fx-text-fill: Red;");
            textField.setStyle("-fx-text-fill: Red;");

            return false;
        }
    }
}
