package lk.ijse.finalProject.controller;

import com.jfoenix.controls.JFXComboBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import lk.ijse.finalProject.Model.Customer;
import lk.ijse.finalProject.Model.Item;
import lk.ijse.finalProject.Model.tm.ItemTm;
import lk.ijse.finalProject.Repositories.CustomerRepo;
import lk.ijse.finalProject.Repositories.ItemRepo;
import lk.ijse.finalProject.controller.Util.Regex;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class ItemFormController implements Initializable {

    public AnchorPane rootNode;
    public TableView<ItemTm> tblItemView;
    public TableColumn<?,?> clmItem;
    public TableColumn<?,?> clmPrice;
    public TableColumn<?,?> clmQty;
    public TextField txtPrice;
    public TextField txtId;
    public TextField txtQty;
    public TextField txtName;
    public JFXComboBox<String> comboId;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setTable();
        setCellValueFactory();
        setCombo();
    }

    private void setCombo() {
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<String> idList = ItemRepo.getId();
            for (String id : idList)
                obList.add(id);
            comboId.setItems(obList);
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    private void setCellValueFactory() {
        clmItem.setCellValueFactory(new PropertyValueFactory<>("name"));
        clmPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        clmQty.setCellValueFactory(new PropertyValueFactory<>("qty"));
    }

    private void setTable() {
        ObservableList<ItemTm> obList = FXCollections.observableArrayList();
        try {
            List<Item> cuslist = ItemRepo.getAll();
           for (Item item : cuslist){
               ItemTm tm = new ItemTm(
                       item.getItem_id(),
                       item.getItem_name(),
                       item.getPrice(),
                       item.getItem_qty()
               );
               obList.add(tm);
               tblItemView.setItems(obList);
           }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    public void btnDeleteOnAction(ActionEvent actionEvent) {
        String id = comboId.getValue();
        String name = txtName.getText();
        double price = Double.parseDouble(txtPrice.getText());
        int qty = Integer.parseInt(txtQty.getText());
        Item item = new Item(id,name,price,qty);
        try {
            boolean isUpdated = ItemRepo.delete(item);
            if (isUpdated){
                setTable();
                setCellValueFactory();
                clearFields();
                new Alert(Alert.AlertType.CONFIRMATION,"Deleted Successfully").show();
                setCombo();
            } else {
                new Alert(Alert.AlertType.ERROR,"Deleted Unsuccessfully").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }
    }

    public void btnAddOnAction(ActionEvent actionEvent) {
        String name = txtName.getText();
        double price = Double.parseDouble(txtPrice.getText());
        int qty = Integer.parseInt(txtQty.getText());
        try {
            String currentID = ItemRepo.getCurrentID();
            String nextid = ItemRepo.getNextid(currentID);
            Item item = new Item(nextid,name,price,qty);
            boolean isSaved = ItemRepo.saveItem(item);
            if (isSaved){
                new Alert(Alert.AlertType.CONFIRMATION,"Item saved successfully").show();
                setTable();
            } else {
                new Alert(Alert.AlertType.ERROR,"Item can't save!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }

    }

    public void btnEditOnAction(ActionEvent actionEvent) {
        String id = comboId.getValue();
        String name = txtName.getText();
        double price = Double.parseDouble(txtPrice.getText());
        int qty = Integer.parseInt(txtQty.getText());
        Item item = new Item(id,name,price,qty);
        try {
            boolean isUpdated = ItemRepo.update(item);
            if (isUpdated){
                setTable();
                setCellValueFactory();
                clearFields();
                new Alert(Alert.AlertType.CONFIRMATION,"Updated Successfully").show();
                setCombo();
            } else {
                new Alert(Alert.AlertType.ERROR,"Updated Unsuccessfully").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }

    }

    private void clearFields() {
        txtQty.clear();
        txtPrice.clear();
        txtQty.clear();
    }

    public void comboFillOnAction(ActionEvent actionEvent) {
        String id = comboId.getValue();
        try {
            Item value = ItemRepo.getValue(id);
            txtName.setText(value.getItem_name());
            txtPrice.setText(String.valueOf(value.getPrice()));
            txtQty.setText(String.valueOf(value.getItem_qty()));
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }

    }

    public void btnClearOnAction(ActionEvent actionEvent) {
        txtName.clear();
        txtPrice.clear();
        txtQty.clear();
    }

    public void txtQtyOnkeyrelease(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Qty, txtQty);
    }

    public void txtPriceOnkeyrelease(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Price, txtPrice);
    }

    public void txtItemonkeyrelease(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Name, txtName);
    }
}
