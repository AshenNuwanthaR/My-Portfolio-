package lk.ijse.finalProject.Repositories;

import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.Delivery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeliveryRepo {
    public static String getDeliveryId() throws SQLException {
        String sql = "SELECT Delivery_id FROM Delivery";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
            return resultSet.getString("Delivery_id");
        }
        return null;
    }

    public static void getDeliveryVehicleId() {

    }

    public static String findNextDeliveryId(String deliveryId) throws SQLException {
        Connection connection = Dbconnection.getInstance().getConnection();
        String sql = "SELECT Delivery_id FROM Delivery ORDER BY Delivery_id DESC";
        PreparedStatement pstm = connection.prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()) {
            String current_id = resultSet.getString(1);
            System.out.println("Current ID: " + current_id);

            // Extract numeric part of current ID
            String numericPart = current_id.replaceAll("[^\\d]", "");
            int nextId = Integer.parseInt(numericPart) + 1;

            // Construct next delivery ID
            String nextDeliveryId = "D" + nextId;

            System.out.println("Next ID: " + nextDeliveryId);
            return nextDeliveryId;
        }
        // If no existing delivery IDs found, return a default value
        return "D1";
    }


    public static boolean save(Delivery itemDetail) throws SQLException {
        Connection connection = Dbconnection.getInstance().getConnection();
        String sql = "INSERT INTO Delivery VALUES(?,?,?)";
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1,itemDetail.getId());
        pstm.setString(2,itemDetail.getVehiId());
        pstm.setString(3,itemDetail.getDescription());
        System.out.println("Hello");
        int i = pstm.executeUpdate();
        System.out.println(i);
        return i>0;
    }
}
