package lk.ijse.finalProject.Model.tm;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data

public class CustomerTm {
    private String id;
    private String name;
    private int number;
    private String address;

    public CustomerTm(String name, String address, int contactNumber) {

        this.name = name;
        this.address = address;
        this.number = contactNumber;

    }
}
