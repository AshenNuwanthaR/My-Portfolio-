package lk.ijse.finalProject.Repositories;

import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.Payment;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PaymentRepo {
    public static String generateNextId(String currentId) {
        if (currentId != null){
            String[] split = currentId.split("P");
            int idNum = Integer.parseInt(split[1]);
            return "P" + ++idNum;
        } else {
            return "P1";
        }
    }

    public static String getCurrentId() throws SQLException {
        String sql = "SELECT Payment_id FROM Payment ORDER BY Payment_id DESC LIMIT 1";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
            String dbPaymentId = resultSet.getString("Payment_id");
            return dbPaymentId;
        }
        return null;
    }


    public static boolean savePayment(Payment payment) throws SQLException {
        String sql = "INSERT INTO Payment VALUES(? ,? ,? ,? )";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,payment.getPayment_id());
        pstm.setObject(2,payment.getPayment_price());
        pstm.setObject(3,payment.getDescription());
        pstm.setObject(4,payment.getPayment_methods());
        return pstm.executeUpdate() > 0;
    }
}
