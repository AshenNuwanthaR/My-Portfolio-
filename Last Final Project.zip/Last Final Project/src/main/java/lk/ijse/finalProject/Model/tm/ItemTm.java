package lk.ijse.finalProject.Model.tm;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ItemTm {
    private String id;
    private String name;
    private double price;
    private int qty;
}
