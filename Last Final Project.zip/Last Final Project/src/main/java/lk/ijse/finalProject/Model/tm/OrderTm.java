package lk.ijse.finalProject.Model.tm;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data

public class OrderTm {
    private String Order_id;
    private String Customer_id;
    private String Delivery_id;
    private int qty;
    private String Description;


}
