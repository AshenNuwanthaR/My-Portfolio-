package lk.ijse.finalProject.Repositories;

import javafx.scene.control.Alert;
import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.PlaceOrder;

import java.sql.Connection;
import java.sql.SQLException;

public class PlaceOrderRepo {


    public static boolean placeOrder(PlaceOrder po) throws SQLException {
        System.out.println("invoke place order");
        Connection connection = Dbconnection.getInstance().getConnection();
        connection.setAutoCommit(false);
        try {
            System.out.println("invoke to try catch");
            boolean isSaved = DeliveryRepo.save(po.getDelivery());
            System.out.println(isSaved);
            System.out.println("awaaaaa");
            if (isSaved) {
                System.out.println("invoke to save1");
                boolean isOk = OrderRepo.save(po.getOrder());
                if (isOk) {
                    System.out.println("invoke save2");
                    boolean save = ItemOrderDetailRepo.save(po.getItemDetail());
                    if (save) {
                        System.out.println("invoke save3");
                        int qty = po.getOrder().getQty();
                        boolean isUpdated = ItemRepo.updateItem(po.getItemDetail(), qty);
                        if (isUpdated) {
                            System.out.println("is commited ?");
                            connection.commit();
                            return true;
                        }
                    }
                }
            }
            connection.rollback();
            return false;
        } catch (Exception e) {
            e.printStackTrace();
//            connection.rollback();
//
            return false;
        } finally {
            connection.setAutoCommit(true);
        }
    }
}
