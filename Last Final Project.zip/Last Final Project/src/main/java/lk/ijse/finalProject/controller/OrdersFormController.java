package lk.ijse.finalProject.controller;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.jetbrains.annotations.NotNull;
//import animatefx.animation.Pulse;
import com.jfoenix.controls.JFXComboBox;
import com.mysql.cj.x.protobuf.MysqlxCrud;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.*;
import lk.ijse.finalProject.Model.tm.OrderTm;
import lk.ijse.finalProject.Repositories.*;
import lk.ijse.finalProject.controller.Util.Regex;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;


public class OrdersFormController implements Initializable {
    public  AnchorPane rootNode;
    public JFXComboBox<String> comboId;
    public TableView<OrderTm> tblOrderDetail;
    public TableColumn<?,?> clmorderid;
    public TableColumn<?,?> clmqty;
    public TableColumn<?,?> clmDescrption;
    public TextField txtQty;
    public JFXComboBox<String> comboItems;
    public JFXComboBox<String> comboVehicle;
    public JFXComboBox<String> comboCusId;
    public JFXComboBox<String> comboPrintbill;


    public void btnSaveOnAction(ActionEvent actionEvent) {
        System.out.println("Start");
        int qty = Integer.parseInt(txtQty.getText());
        String description = comboItems.getValue();
        String cusId = comboCusId.getValue();
        String vehiId = comboVehicle.getValue();

        try {
            System.out.println("start try catch");
            String currentID = OrderRepo.getCurrentID();
            String nextid = OrderRepo.getNextid(currentID);

            String ids = ItemRepo.getIds(description);
            String deliveryId = DeliveryRepo.getDeliveryId();

            String nextDeliveryId = DeliveryRepo.findNextDeliveryId(deliveryId);

            var order = new Order(nextid,cusId,nextDeliveryId,qty,description);

            var delivery = new Delivery(nextDeliveryId,vehiId,description);

            var od = new ItemOrderDetails(nextid,ids);
            PlaceOrder po = new PlaceOrder(order,od,delivery);
            boolean ok = PlaceOrderRepo.placeOrder(po);
            if (ok){
                new Alert(Alert.AlertType.CONFIRMATION,"Order placed successfully").show();
                setTable();

            } else {
                new Alert(Alert.AlertType.ERROR,"Order placed unsuccessfully").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }
    }




    public void comboIdonAction(ActionEvent actionEvent) {

    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setTable();
        setComboPrintbill();
        setCellValueFactory();
        setComboItem();
        setComboVehicle();
        setComboCusId();

    }

    private void setComboCusId()  {
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<String> cusId = CustomerRepo.getCusId();
            for (String id : cusId){
                obList.add(id);
            }
            comboCusId.setItems(obList);
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }
    }

    private void setComboVehicle() {
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<String> deliveryVehicleId = VehicleRepo.getDeliveryVehicleId();
            for (String id : deliveryVehicleId){
                obList.add(id);
            }
            comboVehicle.setItems(obList);
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }
    }

    private void setComboItem() {
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<String> item = ItemRepo.getItem();
            for (String items : item){
                obList.add(items);
            }
            comboItems.setItems(obList);

        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }
    }

    private void setCellValueFactory() {
        clmorderid.setCellValueFactory(new PropertyValueFactory<>("Order_id"));
        clmqty.setCellValueFactory(new PropertyValueFactory<>("Qty"));
        clmDescrption.setCellValueFactory(new PropertyValueFactory<>("Description"));

    }

    private void setTable() {
        ObservableList<OrderTm> obList = FXCollections.observableArrayList();
        try {
            List<Order> cuslist = OrderRepo.getAll();
            for (Order order : cuslist){
                OrderTm tm = new OrderTm(
                        order.getOrder_id(),
                        order.getCustomer_id(),
                        order.getDelivery_id(),
                        order.getQty(),
                        order.getDescription()
                );
                obList.add(tm);
                tblOrderDetail.setItems(obList);
            }
        } catch (SQLException e){
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    public void txtQtyonreleaseonkey(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Qty, txtQty);
    }

    public void btnPrintBillActon(ActionEvent actionEvent) throws SQLException, JRException {
        JasperDesign jasperDesign = JRXmlLoader.load("src/main/resources/reports/Blank_A4_1.jrxml");
        JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

        Map<String,Object> data = new HashMap<>();
        data.put("Parameter1",comboPrintbill.getSelectionModel().getSelectedItem());

        JasperPrint jasperPrint =
                JasperFillManager.fillReport(jasperReport, data, Dbconnection.getInstance().getConnection());
        JasperViewer.viewReport(jasperPrint,false);

    }
private void setComboPrintbill(){
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<String> idList = OrderRepo.getId();
            for (String id : idList)
                obList.add(id);
            comboPrintbill.setItems(obList);
        }catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }




//    private void setCombo() {
//        ObservableList<String> obList = FXCollections.observableArrayList();
//        try {
//            List<String> idList = OrderRepo.getId();
//            for (String id : idList)
//                obList.add(id);
//            comboId.setItems(obList);
//        } catch (SQLException e) {
//            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
//        }
 //   }
}
