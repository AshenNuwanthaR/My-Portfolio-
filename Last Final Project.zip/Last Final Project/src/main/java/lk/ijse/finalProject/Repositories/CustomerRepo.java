package lk.ijse.finalProject.Repositories;

import javafx.scene.control.Alert;
import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.Customer;
import lombok.SneakyThrows;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerRepo {

    public static void registerCustomer(String usename, String password, String repassword) throws SQLException {
        String sql ="INSERT INTO User VALUES(?,?,?)";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,usename);
        pstm.setObject(2,password);
        pstm.setObject(3,repassword);
        int i= pstm.executeUpdate();
        if (i>0){
            new Alert(Alert.AlertType.CONFIRMATION,"User save sucessfully").show();
        }else {
            new Alert(Alert.AlertType.ERROR,"Cant update user datals").show();

        }
    }

    public static String getCurrentId() throws SQLException {
        String sql = "SELECT Customer_id FROM Customers ORDER BY Customer_id DESC LIMIT 1";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
            String dbCustomerId = resultSet.getString("Customer_id");
            return dbCustomerId;
        }
        return null;
    }

    public static String generateNextId(String currentId) {
        if (currentId != null){
            String[] split = currentId.split("C");
            int idNum = Integer.parseInt(split[1]);
            return "C" + ++idNum;
        } else {
            return "C1";
        }
    }

    public static boolean saveCustomer( String id, String name, int number, String address) throws SQLException {
        String sql = "INSERT INTO Customers VALUES(? ,? ,? ,? )";

        Connection connection = Dbconnection.getInstance().getConnection();
        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setObject(1,id);
        pstm.setObject(2,name);
        pstm.setObject(3,number);
        pstm.setObject(4,address);


       int effectedRows = pstm.executeUpdate();
       return effectedRows > 0;
    }

    public static List<Customer> getCustomer() throws SQLException {
        String sql = "SELECT * FROM Customers";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        List<Customer> dbList = new ArrayList<>();
        while (resultSet.next()){
            String customerId = resultSet.getString("Customer_id");
            String customerName = resultSet.getString("Customer_name");
            int contactNumber = Integer.parseInt(resultSet.getString("Contact_number"));
            String address = resultSet.getString("Address");
            Customer customer = new Customer(customerId,customerName,contactNumber,address);
            dbList.add(customer);
        }
        return dbList;
    }

    public static List<String> getId() throws SQLException {

        String sql = "SELECT Customer_id FROM Customers";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        List<String> idList = new ArrayList<>();
        while (resultSet.next()){
           idList.add(resultSet.getString("Customer_id"));
        }
        return idList;
    }



    public static boolean update(Customer customer) throws SQLException {
        String sql = "UPDATE Customers SET Customer_name = ?,Contact_number = ?,Address = ? WHERE Customer_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,customer.getName());
        pstm.setObject(2,customer.getContactNumber());
        pstm.setObject(3,customer.getAddress());
        pstm.setObject(4,customer.getCustomer_id());
        return pstm.executeUpdate() > 0;
    }

    @SneakyThrows
    public static List<Customer> getValue(String id) throws SQLException {
        String sql = "SELECT * FROM Customers WHERE Customer_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,id);
        ResultSet resultSet = pstm.executeQuery();
        List<Customer> cusList = new ArrayList<>();

        if (resultSet.next()){
            String dbId= resultSet.getString(1);
            String name = resultSet.getString(2);
            int tel = resultSet.getInt(3);
            String address = resultSet.getString(4);
            Customer customer = new Customer(dbId,name,tel,address);
            cusList.add(customer);
        }
        return cusList;
    }

    public static boolean delete(String id) throws SQLException {
        String sql = "DELETE FROM Customers WHERE Customer_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,id);
        return pstm.executeUpdate() > 0;
    }

    public static List<String> getCusId() throws SQLException {
        List<String> cusId = new ArrayList<>();
        String sql = "SELECT Customer_id FROM Customers";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        while (resultSet.next()){
            cusId.add(resultSet.getString(1));
        }
        return cusId;
    }
}
