package lk.ijse.finalProject.Repositories;

import javafx.scene.control.ChoiceBox;
import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.Order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderRepo {


    public static List<Order> getAll() throws SQLException {
        String sql = "SELECT * FROM Orders";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        List<Order> cusList = new ArrayList<>();
        while (resultSet.next()){
            String id = resultSet.getString(1);
            String cusId = resultSet.getString(2);
            String deliId = resultSet.getString(3);
            int qty = Integer.parseInt(resultSet.getString(4));
            String description = resultSet.getString(5);
            Order order = new Order(id,cusId,deliId,qty,description);
            cusList.add(order);
        }
        return cusList;
    }

    public static List<String> getid() throws SQLException {
        String sql = "SELECT Order_id FROM Orders";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        List<String > id = new ArrayList<>();
        ResultSet resultSet = pstm.executeQuery();
        while (resultSet.next()){
            String dbId = resultSet.getString(1);
            id.add(dbId);
        }
        return id;

    }

    public static List<String> getId() throws SQLException {
        String sql = "SELECT Order_id FROM Orders";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        List<String > id = new ArrayList<>();
        ResultSet resultSet = pstm.executeQuery();
        while (resultSet.next()){
            String dbId = resultSet.getString(1);
            id.add(dbId);
        }
        return id;
    }

    public static String getCurrentID() throws SQLException {
        String sql = "SELECT Order_id FROM Orders ORDER BY Order_id DESC LIMIT 1";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
            String dbId = resultSet.getString(1);
            return dbId;
        }
        return null;
    }

    public static String getNextid(String currentID) {
        if (currentID != null){
            String[] split = currentID.split("O");
            int idNum = Integer.parseInt(split[1]);
            return "O" + ++idNum;
        }
        return "O1";
    }

    public static boolean save(Order order) throws SQLException {
        System.out.println("orderRepo");
        String sql = "INSERT INTO Orders VALUES (?,?,?,?,?)";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,order.getOrder_id());
        pstm.setObject(2,order.getCustomer_id());
        pstm.setObject(3,order.getDelivery_id());
        pstm.setObject(4,order.getQty());
        pstm.setObject(5,order.getDescription());
        System.out.println("return");
        return pstm.executeUpdate() > 0;

    }

    public static List<Order> getValue(String id) {
        return null;
    }
}
