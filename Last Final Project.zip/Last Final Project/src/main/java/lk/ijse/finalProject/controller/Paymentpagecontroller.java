package lk.ijse.finalProject.controller;

import com.jfoenix.controls.JFXComboBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import lk.ijse.finalProject.Model.Order;
import lk.ijse.finalProject.Model.Payment;
import lk.ijse.finalProject.Repositories.OrderRepo;
import lk.ijse.finalProject.Repositories.PaymentRepo;
import lk.ijse.finalProject.controller.Util.Regex;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class Paymentpagecontroller {
    public AnchorPane rootNode;
    public TextField txtpaymentmethod;
    public TextField txtdescription;
    public TextField txtPayment;



    public void btncancelaction(ActionEvent actionEvent) {

    }

    public void btnPayaction(ActionEvent actionEvent) {
        double paymentprice = Double.parseDouble(txtPayment.getText());
        String description = txtdescription.getText();
        String paymentmethod = txtpaymentmethod.getText();

        try {
            String currentId = PaymentRepo.getCurrentId();
            String nextId = PaymentRepo.generateNextId(currentId);
            Payment payment = new Payment(nextId, paymentprice, description, paymentmethod);
            boolean isTrue = PaymentRepo.savePayment(payment);
            if (isTrue) {
                new Alert(Alert.AlertType.CONFIRMATION,"Payment saved successfully").show();
            } else {
                new Alert(Alert.AlertType.ERROR,"Payment saved unsuccessfully").show();
            }
        } catch (SQLException e){
            new Alert(Alert.AlertType.ERROR,e.getMessage()).show();
        }


    }

    public void btnclearaction(ActionEvent actionEvent) {
        txtPayment.clear();
        txtdescription.clear();
        txtpaymentmethod.clear();
    }

    public void txtPaymentpriceOnkeyrelesed(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Price, txtPayment);
    }

    public void txtPaymentmethodOnkeyreleased(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Name, txtpaymentmethod);
    }

    public void txtDescriptionOnkeyreleased(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Address, txtdescription);

    }


}
