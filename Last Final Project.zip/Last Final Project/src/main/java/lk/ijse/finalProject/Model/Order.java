package lk.ijse.finalProject.Model;

public class Order {
    private String Order_id;
    private String Customer_id;
    private String Delivery_id;
    private int qty;
    private String Description;

    public Order(String order_id, String customer_id, String delivery_id, int qty, String description) {
        Order_id = order_id;
        Customer_id = customer_id;
        Delivery_id = delivery_id;
        this.qty = qty;
        Description = description;
    }

    public Order() {
    }

    public String getOrder_id() {
        return Order_id;
    }

    public void setOrder_id(String order_id) {
        Order_id = order_id;
    }

    public String getCustomer_id() {
        return Customer_id;
    }

    public void setCustomer_id(String customer_id) {
        Customer_id = customer_id;
    }

    public String getDelivery_id() {
        return Delivery_id;
    }

    public void setDelivery_id(String delivery_id) {
        Delivery_id = delivery_id;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    @Override
    public String toString() {
        return "Order{" +
                "Order_id='" + Order_id + '\'' +
                ", Customer_id='" + Customer_id + '\'' +
                ", Delivery_id='" + Delivery_id + '\'' +
                ", qty=" + qty +
                ", Description='" + Description + '\'' +
                '}';
    }
}
