package lk.ijse.finalProject.controller;

import com.jfoenix.controls.JFXComboBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import lk.ijse.finalProject.Model.Customer;
import lk.ijse.finalProject.controller.Util.Regex;
import lk.ijse.finalProject.Model.tm.CustomerTm;
import lk.ijse.finalProject.Repositories.CustomerRepo;

import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class CustomerFormController implements Initializable {
    public TextField txtName;
    public TextField txtAddress;
    public TextField txtNumber;
    public TableView<CustomerTm> tblCustomerDetail;
    public TableColumn<?, ?> clmCustomer;
    public TableColumn<?, ?> clmAddress;
    public TableColumn<?, ?> clmNumber;
    public JFXComboBox<String> comboId;
    public BorderPane rootNode;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setCombo();
        loadAllCustomer();
        setCellValueFactory();
    }

    private void setCombo() {
        ObservableList<String> obList = FXCollections.observableArrayList();
        try {
            List<String> id = CustomerRepo.getId();
            for (String ids : id) {
                obList.add(ids);
                comboId.setItems(obList);
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    private void setCellValueFactory() {
        clmCustomer.setCellValueFactory(new PropertyValueFactory<>("name"));
        clmAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        clmNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
    }

    private void loadAllCustomer() {
        ObservableList<CustomerTm> obList = FXCollections.observableArrayList();
        try {
            List<Customer> cusList = CustomerRepo.getCustomer();
            for (Customer customer : cusList) {
                CustomerTm tm = new CustomerTm(
                        customer.getName(),
                        customer.getAddress(),
                        customer.getContactNumber()
                );
                obList.add(tm);
                tblCustomerDetail.setItems(obList);
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    public void btnSaveOnAction(ActionEvent actionEvent) {
        String name = txtName.getText();
        String address = txtAddress.getText();
        int number = Integer.parseInt(txtNumber.getText());

        if (isValied()){
            try {
                String currentId = CustomerRepo.getCurrentId();
                String nextId = CustomerRepo.generateNextId(currentId);

                boolean isSave = CustomerRepo.saveCustomer(nextId, name, number, address);
                if (isSave) {
                    new Alert(Alert.AlertType.CONFIRMATION, "Customer saved successfully", ButtonType.OK).show();
                    setCombo();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Customer saved unsuccessfully", ButtonType.OK).show();

                }
            } catch (SQLException e) {
                new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
            }
        loadAllCustomer();
    }
}

    public void btnEditOnAction(ActionEvent actionEvent) {
            String id = comboId.getValue();
            String name = txtName.getText();
            int tel= Integer.parseInt(txtNumber.getText());
            String address = txtAddress.getText();
            Customer customer = new Customer(id,name,tel,address);
        if (isValied()) {
            try {
                boolean isUpdated = CustomerRepo.update(customer);
                if (isUpdated) {
                    new Alert(Alert.AlertType.CONFIRMATION, "Customer update successfully").show();
                    setCombo();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Customer can't update").show();
                }
            } catch (SQLException e) {
                new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
            }
        }

    }

    public void btnDeleteOnAction(ActionEvent actionEvent) {
        String id = comboId.getValue();
        try {
            boolean isDeleted = CustomerRepo.delete(id);
            if (isDeleted){
                new Alert(Alert.AlertType.CONFIRMATION,"Customer deleted successfully").show();
                setCombo();
            } else {
                new Alert(Alert.AlertType.ERROR,"Customer deleted unsuccessfully!!!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }

    }

    public void comboIdonAction(ActionEvent actionEvent) {
        String id = comboId.getValue();
        try {
            List<Customer> customerList = CustomerRepo.getValue(id);
            for (Customer customer : customerList){
                txtName.setText(customer.getName());
                txtAddress.setText(customer.getAddress());
                txtNumber.setText(String.valueOf(customer.getContactNumber()));
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }


    public void txtAddressOnKeyReleased(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Address, txtAddress);

    }

    public void txtNameOnKeyReleased(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Name, txtName);
    }

    public void txtNumberOnKeyReleased(KeyEvent keyEvent) {
        Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Number, txtNumber);
    }
    public boolean isValied(){
        if (!Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Name, txtName))return false;
        if (!Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Address, txtAddress))return false;
        if (!Regex.setTextColour(lk.ijse.finalProject.controller.Util.TextField.Number, txtNumber))return false;

        return true;
    }

    public void btnClaerOnAction(ActionEvent actionEvent) {
        txtName.clear();
        txtNumber.clear();
        txtAddress.clear();
    }
}
