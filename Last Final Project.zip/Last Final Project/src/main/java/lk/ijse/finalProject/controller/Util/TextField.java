package lk.ijse.finalProject.controller.Util;

import javafx.scene.paint.Paint;

import javax.lang.model.element.Name;

public enum TextField {
    Name,Number,Address,Price,Qty

}
