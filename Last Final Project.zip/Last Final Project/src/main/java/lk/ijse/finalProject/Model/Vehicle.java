package lk.ijse.finalProject.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Vehicle {
    private String vehicleId;
    private String driverId;
    private String number_plate;
    private String yom;
    private String color;

}
