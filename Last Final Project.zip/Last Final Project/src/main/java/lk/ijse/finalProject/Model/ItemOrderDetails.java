package lk.ijse.finalProject.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ItemOrderDetails {
    private String order_id;
    private String item_id;
}
