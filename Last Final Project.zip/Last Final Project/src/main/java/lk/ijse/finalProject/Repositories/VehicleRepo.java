package lk.ijse.finalProject.Repositories;

import lk.ijse.finalProject.DB.Dbconnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VehicleRepo {
    public static List<String > getDeliveryVehicleId() throws SQLException {
        List<String> vehiId = new ArrayList<>();
        String sql = "SELECT Vehicle_id FROM Vehicle";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        while (resultSet.next()){
            vehiId.add(resultSet.getString(1));
        }
        return vehiId;
    }
}
