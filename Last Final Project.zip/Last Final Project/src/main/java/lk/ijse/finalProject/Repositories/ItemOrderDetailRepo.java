package lk.ijse.finalProject.Repositories;

import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.ItemOrderDetails;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ItemOrderDetailRepo {
    public static boolean save(ItemOrderDetails itemDetail) throws SQLException {
        String sql = "INSERT INTO Item_orders_details VALUES(?,?)";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,itemDetail.getOrder_id());
        pstm.setObject(2,itemDetail.getItem_id());
        return pstm.executeUpdate() > 0;
    }
}
