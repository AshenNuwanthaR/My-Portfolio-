package lk.ijse.finalProject.Model;


public class Item {
    private String Item_id;
    private String Item_name;
    private double Price;
    private int Item_qty;

    public Item() {
    }

    public Item(String item_id, String item_name, double price, int item_qty) {
        Item_id = item_id;
        Item_name = item_name;
        Price = price;
        Item_qty = item_qty;
    }

    public String getItem_id() {
        return Item_id;
    }

    public void setItem_id(String item_id) {
        Item_id = item_id;
    }

    public String getItem_name() {
        return Item_name;
    }

    public void setItem_name(String item_name) {
        Item_name = item_name;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public int getItem_qty() {
        return Item_qty;
    }

    public void setItem_qty(int item_qty) {
        Item_qty = item_qty;
    }

    @Override
    public String toString() {
        return "Item{" +
                "Item_id='" + Item_id + '\'' +
                ", Item_name='" + Item_name + '\'' +
                ", Price=" + Price +
                ", Item_qty=" + Item_qty +
                '}';
    }
}
