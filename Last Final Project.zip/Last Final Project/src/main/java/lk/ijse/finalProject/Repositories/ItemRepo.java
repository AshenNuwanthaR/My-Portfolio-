package lk.ijse.finalProject.Repositories;

import lk.ijse.finalProject.DB.Dbconnection;
import lk.ijse.finalProject.Model.Item;
import lk.ijse.finalProject.Model.ItemOrderDetails;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemRepo {
    public static String getCurrentID() throws SQLException {
        String sql = "SELECT item_id FROM Item ORDER BY item_id DESC LIMIT 1";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
            String dbId = resultSet.getString(1);
            return dbId;
        }
        return null;
    }

    public static String getNextid(String currentID) {
        if (currentID != null){
            String[] split = currentID.split("I");
            int idNum = Integer.parseInt(split[1]);
            return "I" + ++idNum;
        }
        return "I1";
    }

    public static boolean saveItem(Item item) throws SQLException {
        String sql = "INSERT INTO Item VALUES(?, ?, ?, ? )";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,item.getItem_id());
        pstm.setObject(2,item.getItem_name());
        pstm.setObject(3,item.getPrice());
        pstm.setObject(4,item.getItem_qty());
        return pstm.executeUpdate() > 0;

    }

    public static List<Item> getAll() throws SQLException {
        String sql = "SELECT * FROM Item";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        List<Item> cusList = new ArrayList<>();
        while (resultSet.next()){
            String id = resultSet.getString(1);
            String name = resultSet.getString(2);
            double price = Double.parseDouble(resultSet.getString(3));
            int qty = Integer.parseInt(resultSet.getString(4));
            Item item = new Item(id,name,price,qty);
            cusList.add(item);
        }
        return cusList;
    }

    public static List<String> getId() throws SQLException {
        String sql = "SELECT item_id FROM Item";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        List<String > id = new ArrayList<>();
        ResultSet resultSet = pstm.executeQuery();
        while (resultSet.next()){
            String dbId = resultSet.getString(1);
            id.add(dbId);
        }
        return id;
    }

    public static Item getValue(String id) throws SQLException {
        String sql = "SELECT * FROM Item WHERE item_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,id);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
            String dbId = resultSet.getString(1);
            String name = resultSet.getString(2);
            double price = resultSet.getDouble(3);
            int qty = resultSet.getInt(4);

            Item item = new Item(dbId,name,price,qty);
            return item;
        }
        return null;
    }

    public static boolean update(Item item) throws SQLException {
        String sql = "UPDATE Item SET item_id = ? , item_name = ? , price = ?, item_qty = ? WHERE item_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,item.getItem_id());
        pstm.setObject(2,item.getItem_name());
        pstm.setObject(3,item.getPrice());
        pstm.setObject(4,item.getItem_qty());
        pstm.setObject(5,item.getItem_id());
        return pstm.executeUpdate() > 0;
    }

    public static boolean delete(Item item) throws SQLException {
        String sql = "DELETE FROM Item WHERE item_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,item.getItem_id());

        return pstm.executeUpdate() > 0;
    }

    public static List<String > getItem() throws SQLException {
        String sql = "SELECT Item_name FROM Item";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        ResultSet resultSet = pstm.executeQuery();
        List<String> itemList = new ArrayList<>();
        while (resultSet.next()){
            itemList.add(resultSet.getString("Item_name"));
        }
        return itemList;
    }

    public static String getIds(String value) throws SQLException {
        String sql = "SELECT Item_id FROM Item WHERE Item_name = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,value);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
             return resultSet.getString("Item_id");
        }
        return null;
    }

    public static boolean updateItem(ItemOrderDetails itemDetail, int qty) throws SQLException {
        String sql = "UPDATE Item SET Item_qty = Item_qty - ? WHERE Item_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setInt(1,qty);
        pstm.setString(2,itemDetail.getItem_id());
        return pstm.executeUpdate() > 0;
    }

    public static String getCurrentQty(String itemId) throws SQLException {
        String sql = "SELECT Item_qty FROM Item WHERE Item_id = ?";
        PreparedStatement pstm = Dbconnection.getInstance().getConnection().prepareStatement(sql);
        pstm.setObject(1,itemId);
        ResultSet resultSet = pstm.executeQuery();
        if (resultSet.next()){
           return resultSet.getString("Item_qty");

        }
        return null;
    }
}
