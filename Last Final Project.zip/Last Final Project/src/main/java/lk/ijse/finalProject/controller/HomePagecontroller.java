package lk.ijse.finalProject.controller;

//import animatefx.animation.Pulse;
import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Paint;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HomePagecontroller implements Initializable {

    public AnchorPane pane;
    public BorderPane rootNode;
    public JFXButton btnitem;
    public JFXButton btnOrder;
    public JFXButton btncustomer;
    public JFXButton btnbilling;
    public JFXButton btndashbord;

    @FXML
    private PieChart pieChart;


    @FXML
    private LineChart<?,?> Linechart;


    public void btnlogoutaction(ActionEvent actionEvent) throws IOException {

        AnchorPane pane = FXMLLoader.load(this.getClass().getResource("/view/loginForm.fxml"));
        this.rootNode.getChildren().clear();
        this.rootNode.getChildren().add(pane);
        //new Pulse(rootNode).play();

    }

    public void btnDashboardaction(ActionEvent actionEvent) throws IOException {
        btnitem.setTextFill(Paint.valueOf("black"));
        btnbilling.setTextFill(Paint.valueOf("black"));
        btncustomer.setTextFill(Paint.valueOf("black"));
        Parent parent = FXMLLoader.load(this.getClass().getResource("/view/homePage.fxml"));
        this.rootNode.getChildren().clear();
        this.rootNode.getChildren().add(parent);
       // new Pulse(rootNode).play();


    }


    public void btnbillingaction(ActionEvent actionEvent) throws IOException {
        btndashbord.setTextFill(Paint.valueOf("black"));
        btnOrder.setTextFill(Paint.valueOf("black"));
        btnitem.setTextFill(Paint.valueOf("black"));
        btncustomer.setTextFill(Paint.valueOf("black"));
        btndashbord.setTextFill(Paint.valueOf("black"));
        btnbilling.setTextFill(Paint.valueOf("blue"));
        Parent parent = FXMLLoader.load(this.getClass().getResource("/view/paymentpage.fxml"));
        this.pane.getChildren().clear();
        this.pane.getChildren().add(parent);
        //new Pulse(pane).play();
    }

    public void btncustomeraction(ActionEvent actionEvent) throws IOException {
        btndashbord.setTextFill(Paint.valueOf("black"));
        btnOrder.setTextFill(Paint.valueOf("black"));
        btnitem.setTextFill(Paint.valueOf("black"));
        btnbilling.setTextFill(Paint.valueOf("black"));
        btndashbord.setTextFill(Paint.valueOf("black"));
        btncustomer.setTextFill(Paint.valueOf("blue"));
        Parent parent = FXMLLoader.load(this.getClass().getResource("/view/customerForm.fxml"));
        this.pane.getChildren().clear();
        this.pane.getChildren().add(parent);
        //new Pulse(pane).play();
    }
    public void btnItemaction(ActionEvent actionEvent) throws IOException {
        btndashbord.setTextFill(Paint.valueOf("black"));
        btnOrder.setTextFill(Paint.valueOf("black"));
        btnbilling.setTextFill(Paint.valueOf("black"));
        btncustomer.setTextFill(Paint.valueOf("black"));
        btndashbord.setTextFill(Paint.valueOf("black"));
        btnitem.setTextFill(Paint.valueOf("blue"));
        AnchorPane rootNode = FXMLLoader.load(this.getClass().getResource("/view/itemForm.fxml"));
        this.pane.getChildren().clear();
        this.pane.getChildren().add(rootNode);
       // new Pulse(pane).play();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        XYChart.Series series = new XYChart.Series();

        series.getData().add(new XYChart.Data("1",23));
        series.getData().add(new XYChart.Data("2",13));
        series.getData().add(new XYChart.Data("3",43));
        series.getData().add(new XYChart.Data("4",55));
        series.getData().add(new XYChart.Data("5",22));
        series.getData().add(new XYChart.Data("6",12));

        XYChart.Series series2 = new XYChart.Series();

        series2.getData().add(new XYChart.Data("1",17));
        series2.getData().add(new XYChart.Data("2",35));
        series2.getData().add(new XYChart.Data("3",63));
        series2.getData().add(new XYChart.Data("4",12));
        series2.getData().add(new XYChart.Data("5",60));
        series2.getData().add(new XYChart.Data("6",80));



       Linechart.getData().addAll(series,series2);

        ObservableList<PieChart.Data> pieChartData =
                FXCollections.observableArrayList(
                        new PieChart.Data("Items",56),
                        new PieChart.Data("Payment",35),
                        new PieChart.Data("Order",67));

        pieChart.getData().addAll(pieChartData);


    }

    public void btnOrderaction(ActionEvent actionEvent) throws IOException {
        btndashbord.setTextFill(Paint.valueOf("black"));
        btnitem.setTextFill(Paint.valueOf("black"));
        btnbilling.setTextFill(Paint.valueOf("black"));
        btncustomer.setTextFill(Paint.valueOf("black"));
        btnOrder.setTextFill(Paint.valueOf("blue"));
        AnchorPane rootNode = FXMLLoader.load(this.getClass().getResource("/view/OrdersForm.fxml"));
        this.pane.getChildren().clear();
        this.pane.getChildren().add(rootNode);
        //new Pulse(pane).play();
    }


}

