package lk.ijse.dep.service;

public enum Piece {
    GREEN,BLUE,EMPTY
}
